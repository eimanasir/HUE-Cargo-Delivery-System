﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace HUE
{
    public partial class CustomerLogin : Form
    {
        private bool Verify()
        {
            string path = @"Data Source=HADI2023\SQLEXPRESS;Initial Catalog=HUE;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();

            string query = "SELECT * FROM CUSTOMER WHERE EMAIL = '"+bunifuTextBox1.Text+"' AND PASSWORD = '"+bunifuTextBox2.Text+"'";
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows == true)
            {
                return true;
            }
            else
            {
                return false;
            }

            command.Dispose();
            Connection.Close();

        }
        public CustomerLogin()
        {
            InitializeComponent();
        }

        private void bunifuPanel1_Click(object sender, EventArgs e)
        {
                
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            FrontForm title = new FrontForm();
            title.ShowDialog();
        }

        private void CustomerLogin_Load(object sender, EventArgs e)
        {

        }

        private void bunifuLabel2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click_1(object sender, EventArgs e)
        {
            FrontForm title = new FrontForm();
            title.Show();
            this.Hide();

        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            CustomerSignup signup = new CustomerSignup();
            signup.Show();
            this.Hide();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if(Verify() == true)
            {
                CustomerMain main = new CustomerMain();
                main.Show();
                this.Hide();
            }
        }
    }
}
