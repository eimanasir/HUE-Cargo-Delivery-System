﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HUE
{
    public partial class CustomerMain : Form
    {
        private void Insert()
        {
            string path = @"Data Source=HADI2023\SQLEXPRESS;Initial Catalog=HUE;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();

            string query = "INSERT INTO ITEM (NAME, DESTINATION  ,WEIGHT , VALUE) VALUES ('" + bunifuTextBox1.Text + "' , '" + bunifuTextBox2.Text + "','" + bunifuTextBox3.Text + "','" + bunifuTextBox4.Text + "')";
            SqlCommand command = new SqlCommand(query, Connection);
            command.ExecuteNonQuery();



            command.Dispose();
            Connection.Close();

        }
        public CustomerMain()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuPanel1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Insert();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerLogin login = new CustomerLogin();
            login.Show();
           
        }
    }
}
