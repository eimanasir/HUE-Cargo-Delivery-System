﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HUE
{
    public partial class CustomerSignup : Form
    {

        private void Insert()
        {
            string path = @"Data Source=HADI2023\SQLEXPRESS;Initial Catalog=HUE;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();

            string query = "INSERT INTO CUSTOMER (NAME, EMAIL  ,PHONE, AGE, PASSWORD) VALUES ('" + bunifuTextBox1.Text + "' , '" + bunifuTextBox2.Text + "','" + bunifuTextBox3.Text + "','" + bunifuTextBox4.Text + "','" + bunifuTextBox5.Text + "')";
            SqlCommand command = new SqlCommand(query, Connection);
            command.ExecuteNonQuery();



            command.Dispose();
            Connection.Close();

        }

        public CustomerSignup()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void bunifuLabel2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            Insert();

        }
    }
}
